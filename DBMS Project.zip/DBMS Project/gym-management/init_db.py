﻿"""Create gym.db from schema.sql and fill it with realistic sample data.
Run:  python init_db.py
"""
import os
import random
import re
import sqlite3
from datetime import date, datetime, timedelta

HERE = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(HERE, "gym.db")
random.seed(42)
today = date.today()

PLANS = [
    ("Day Pass", 1, 150, "Single day access to gym floor"),
    ("Monthly Basic", 30, 1200, "Gym floor access, locker"),
    ("Monthly Plus", 30, 1800, "Gym floor + unlimited group classes"),
    ("Quarterly", 90, 4500, "3 months, classes + 1 free PT session"),
    ("Half-Yearly", 180, 8000, "6 months, classes + 3 free PT sessions"),
    ("Annual Elite", 365, 14000, "12 months, all access + monthly body analysis"),
]
TRAINERS = [
    ("Arjun Mehta", "Strength & Powerlifting", "9810011001", "arjun@ironpulse.fit", 800),
    ("Sara Khan", "Yoga & Mobility", "9810011002", "sara@ironpulse.fit", 600),
    ("Rohit Patil", "HIIT & Cardio", "9810011003", "rohit@ironpulse.fit", 700),
    ("Neha Joshi", "Zumba & Dance Fitness", "9810011004", "neha@ironpulse.fit", 550),
    ("Vikram Rao", "CrossFit", "9810011005", "vikram@ironpulse.fit", 900),
    ("Priya Nair", "Pilates & Rehab", "9810011006", "priya@ironpulse.fit", 650),
]
CLASSES = [  # name, trainer idx(1-based), day, time, dur, cap, room
    ("Power Lifting 101", 1, "Monday", "07:00", 60, 12, "Studio A"),
    ("Morning Flow Yoga", 2, "Tuesday", "06:30", 60, 15, "Studio B"),
    ("HIIT Blast", 3, "Wednesday", "18:00", 45, 18, "Studio A"),
    ("Zumba Party", 4, "Thursday", "19:00", 60, 25, "Studio C"),
    ("CrossFit WOD", 5, "Friday", "17:30", 60, 14, "Arena"),
    ("Pilates Core", 6, "Saturday", "09:00", 50, 12, "Studio B"),
    ("Sunday Stretch", 2, "Sunday", "08:00", 45, 20, "Studio B"),
    ("Evening Strength", 1, "Wednesday", "19:30", 60, 10, "Studio A"),
    ("Cardio Kickboxing", 3, "Friday", "07:00", 45, 16, "Arena"),
    ("Power Yoga", 2, "Monday", "18:30", 60, 15, "Studio B"),
]
FIRST = ["Aarav", "Vivaan", "Aditya", "Ishaan", "Kabir", "Reyansh", "Rahul", "Karan", "Dev", "Rohan",
         "Ananya", "Diya", "Isha", "Kavya", "Meera", "Naina", "Pooja", "Riya", "Sneha", "Tanvi",
         "Zoya", "Aisha", "Nisha", "Manav", "Yash", "Sahil", "Tara", "Veda", "Om", "Jiya"]
LAST = ["Sharma", "Patil", "Desai", "Kulkarni", "Joshi", "Shah", "Verma", "Iyer", "Reddy", "Gupta",
        "Kapoor", "Menon", "Bose", "Chavan", "Pawar"]
GOALS = ["Weight Loss", "Muscle Gain", "Endurance", "Flexibility", "General Fitness"]
WORKOUTS = {
    "Weight Loss": "Mon: HIIT 30m + core | Tue: Steady cardio 40m | Wed: Full-body circuit | Thu: Rest/Yoga | Fri: HIIT 30m | Sat: Long walk/cycle 60m",
    "Muscle Gain": "Mon: Chest+Triceps | Tue: Back+Biceps | Wed: Legs | Thu: Rest | Fri: Shoulders+Abs | Sat: Full-body compound lifts",
    "Endurance": "Mon: 5km run | Tue: Strength basics | Wed: Intervals 8x400m | Thu: Rest | Fri: Tempo run 30m | Sat: Long run 10km",
    "Flexibility": "Daily: 15m mobility flow | Mon/Thu: Yoga 45m | Wed: Pilates core | Sat: Deep stretch + foam rolling",
    "General Fitness": "Mon: Upper body | Tue: Cardio 30m | Wed: Lower body | Thu: Rest | Fri: Full-body circuit | Sat: Sports/Outdoor",
}


def d(x):
    return x.isoformat()


def main():
    if os.path.exists(DB):
        os.remove(DB)
    schema = open(os.path.join(HERE, "schema.sql"), encoding="utf-8").read()
    con = sqlite3.connect(DB)
    con.executescript(schema)
    con.execute("PRAGMA foreign_keys = ON")

    # Seeding history needs the 'active member' triggers off; they are restored at the end.
    guard_names = ["trg_attendance_requires_active", "trg_booking_requires_active"]
    guard_sql = {}
    for n in guard_names:
        guard_sql[n] = re.search(r"CREATE TRIGGER %s.*?END;" % n, schema, re.S).group(0)
        con.execute("DROP TRIGGER " + n)

    con.executemany("INSERT INTO membership_plans(name,duration_days,price,description) VALUES (?,?,?,?)", PLANS)
    con.executemany("INSERT INTO trainers(name,specialty,phone,email,hourly_rate) VALUES (?,?,?,?,?)", TRAINERS)
    con.executemany("INSERT INTO classes(name,trainer_id,day_of_week,start_time,duration_min,capacity,room) VALUES (?,?,?,?,?,?,?)", CLASSES)

    names = set()
    n_members = 32
    members = []
    while len(members) < n_members:
        nm = f"{random.choice(FIRST)} {random.choice(LAST)}"
        if nm in names:
            continue
        names.add(nm)
        members.append(nm)

    for i, nm in enumerate(members, 1):
        gender = "Female" if FIRST.index(nm.split()[0]) in range(10, 24) else "Male"
        join = today - timedelta(days=random.randint(20, 330))
        dob = date(random.randint(1980, 2005), random.randint(1, 12), random.randint(1, 28))
        plan_id = random.choice([2, 2, 3, 3, 3, 4, 5, 6])
        trainer = random.choice([None] + list(range(1, 7)))
        email = nm.lower().replace(" ", ".") + f"{i}@mail.com"
        cur = con.execute(
            "INSERT INTO members(full_name,email,phone,gender,dob,join_date,plan_id,trainer_id) VALUES (?,?,?,?,?,?,?,?)",
            (nm, email, f"98{random.randint(10000000, 99999999)}", gender, d(dob), d(join), plan_id, trainer))
        mid = cur.lastrowid

        # chain of renewals from join date until a random end point (some expired, some about to)
        target_end = max(today + timedelta(days=random.randint(-30, 45)), join + timedelta(days=1))
        start = join
        first = True
        while start < target_end:
            pid = plan_id if first else random.choice([plan_id, plan_id, 2, 3])
            row = con.execute("SELECT duration_days, price FROM membership_plans WHERE plan_id=?", (pid,)).fetchone()
            end = start + timedelta(days=row[0])
            method = random.choice(["Cash", "Card", "UPI", "UPI", "Bank Transfer"])
            con.execute("INSERT INTO payments(member_id,plan_id,amount,method,paid_on,valid_from,valid_to) VALUES (?,?,?,?,?,?,?)",
                        (mid, pid, row[1], method, d(start), d(start), d(end)))
            start = end
            first = False

        # attendance for the last 45 days while the membership was valid
        exp = con.execute("SELECT expiry_date FROM members WHERE member_id=?", (mid,)).fetchone()[0]
        habit = random.choice([0.25, 0.4, 0.55, 0.7])
        for back in range(45, -1, -1):
            day = today - timedelta(days=back)
            if d(day) > exp or day < join:
                continue
            if random.random() < habit:
                tin = datetime(day.year, day.month, day.day, random.randint(5, 20), random.randint(0, 59))
                tout = tin + timedelta(minutes=random.randint(40, 110))
                if back == 0:  # today: leave some checked-in
                    tout = None if random.random() < 0.5 else tout
                con.execute("INSERT INTO attendance(member_id,check_in,check_out) VALUES (?,?,?)",
                            (mid, tin.strftime("%Y-%m-%d %H:%M:%S"), tout.strftime("%Y-%m-%d %H:%M:%S") if tout else None))

        goal = random.choice(GOALS)
        con.execute("INSERT INTO workout_plans(member_id,trainer_id,title,goal,details,created_on) VALUES (?,?,?,?,?,?)",
                    (mid, trainer, f"{goal} Program", goal, WORKOUTS[goal], d(join + timedelta(days=2))))

    # upcoming bookings for active members
    active = [r[0] for r in con.execute("SELECT member_id FROM members WHERE status='Active' AND expiry_date >= date('now')")]
    classes = con.execute("SELECT class_id, day_of_week, start_time FROM classes").fetchall()
    dow = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
    for cid, day_name, tm in classes:
        delta = (dow.index(day_name) - today.weekday()) % 7
        nxt = today + timedelta(days=delta)
        for mid in random.sample(active, min(len(active), random.randint(3, 9))):
            con.execute("INSERT INTO bookings(member_id,type,class_id,session_date,session_time) VALUES (?,?,?,?,?)",
                        (mid, "Class", cid, d(nxt), tm))
    used = set()
    for _ in range(8):
        mid = random.choice(active)
        tid = random.randint(1, 6)
        day = today + timedelta(days=random.randint(0, 6))
        tm = random.choice(["06:00", "08:00", "10:00", "16:00", "18:00", "20:00"])
        if (tid, d(day), tm) in used:
            continue
        used.add((tid, d(day), tm))
        con.execute("INSERT INTO bookings(member_id,type,trainer_id,session_date,session_time) VALUES (?,?,?,?,?)",
                    ("%d" % mid, "PT", tid, d(day), tm))

    for n in guard_names:
        con.execute(guard_sql[n])
    con.execute("UPDATE members SET status='Expired' WHERE status='Active' AND expiry_date < date('now')")
    con.commit()

    for t in ["membership_plans", "trainers", "members", "classes", "bookings", "payments", "attendance", "workout_plans"]:
        print(f"{t:18s} {con.execute('SELECT COUNT(*) FROM ' + t).fetchone()[0]:5d} rows")
    con.close()
    print("Database created:", DB)


if __name__ == "__main__":
    main()
