"""IronPulse Gym Management System - REST API + static file server.
Pure Python standard library (http.server + sqlite3). Run:  python server.py
Then open http://localhost:8000
"""
import json
import mimetypes
import os
import re
import sqlite3
import sys
from datetime import date, timedelta
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

HERE = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(HERE, "gym.db")
STATIC = os.path.join(HERE, "static")
PORT = int(os.environ.get("PORT", 8000))
DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]

# resource -> (table, pk, writable columns)
RESOURCES = {
    "members": ("members", "member_id",
                ["full_name", "email", "phone", "gender", "dob", "join_date", "plan_id", "trainer_id", "status"]),
    "trainers": ("trainers", "trainer_id", ["name", "specialty", "phone", "email", "hourly_rate", "status"]),
    "plans": ("membership_plans", "plan_id", ["name", "duration_days", "price", "description"]),
    "classes": ("classes", "class_id",
                ["name", "trainer_id", "day_of_week", "start_time", "duration_min", "capacity", "room"]),
    "workouts": ("workout_plans", "workout_id", ["member_id", "trainer_id", "title", "goal", "details"]),
}


class ApiError(Exception):
    def __init__(self, msg, code=400):
        super().__init__(msg)
        self.code = code


def connect(readonly=False):
    if readonly:
        con = sqlite3.connect("file:%s?mode=ro" % DB.replace("\\", "/"), uri=True)
    else:
        con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys = ON")
    return con


def rows(con, sql, args=()):
    return [dict(r) for r in con.execute(sql, args).fetchall()]


def one(con, sql, args=()):
    r = con.execute(sql, args).fetchone()
    return dict(r) if r else None


def refresh_expired(con):
    con.execute("UPDATE members SET status='Expired' WHERE status='Active' AND expiry_date < date('now')")


def next_date_for(day_name):
    delta = (DAYS.index(day_name) - date.today().weekday()) % 7
    return (date.today() + timedelta(days=delta)).isoformat()


# ----------------------------------------------------------------- list queries
def list_members(con, q):
    refresh_expired(con)
    sql = "SELECT * FROM v_member_overview WHERE 1=1"
    args = []
    if q.get("status"):
        sql += " AND status = ?"
        args.append(q["status"])
    if q.get("q"):
        sql += " AND (full_name LIKE ? OR email LIKE ? OR phone LIKE ?)"
        args += ["%" + q["q"] + "%"] * 3
    sql += " ORDER BY member_id DESC"
    out = rows(con, sql, args)
    # attach raw ids for the edit form
    raw = {r["member_id"]: r for r in rows(con, "SELECT member_id, gender, dob, plan_id, trainer_id FROM members")}
    for r in out:
        r.update(raw[r["member_id"]])
    return out


def list_classes(con, q):
    out = rows(con, """SELECT c.*, t.name AS trainer_name FROM classes c
                       JOIN trainers t ON t.trainer_id = c.trainer_id""")
    for c in out:
        c["next_date"] = next_date_for(c["day_of_week"])
        c["booked"] = con.execute(
            "SELECT COUNT(*) FROM bookings WHERE class_id=? AND session_date=? AND status='Booked'",
            (c["class_id"], c["next_date"])).fetchone()[0]
    out.sort(key=lambda c: (DAYS.index(c["day_of_week"]), c["start_time"]))
    return out


def list_bookings(con, q):
    sql = """SELECT b.*, m.full_name AS member_name,
                    COALESCE(c.name, 'Personal Training') AS title,
                    COALESCE(t1.name, t2.name) AS trainer_name
             FROM bookings b
             JOIN members m ON m.member_id = b.member_id
             LEFT JOIN classes  c  ON c.class_id = b.class_id
             LEFT JOIN trainers t1 ON t1.trainer_id = c.trainer_id
             LEFT JOIN trainers t2 ON t2.trainer_id = b.trainer_id
             WHERE 1=1"""
    args = []
    if q.get("upcoming"):
        sql += " AND b.session_date >= date('now') AND b.status='Booked'"
    if q.get("member_id"):
        sql += " AND b.member_id = ?"
        args.append(q["member_id"])
    sql += " ORDER BY b.session_date, b.session_time LIMIT 300"
    return rows(con, sql, args)


def list_payments(con, q):
    sql = """SELECT y.*, m.full_name AS member_name, p.name AS plan_name
             FROM payments y JOIN members m ON m.member_id=y.member_id
             JOIN membership_plans p ON p.plan_id=y.plan_id"""
    args = []
    if q.get("member_id"):
        sql += " WHERE y.member_id=?"
        args.append(q["member_id"])
    sql += " ORDER BY y.paid_on DESC, y.payment_id DESC LIMIT 300"
    return rows(con, sql, args)


def list_attendance(con, q):
    return rows(con, """SELECT a.*, m.full_name AS member_name,
                        CAST((julianday(COALESCE(a.check_out, datetime('now','localtime'))) - julianday(a.check_in))*1440 AS INTEGER) AS minutes
                        FROM attendance a JOIN members m ON m.member_id=a.member_id
                        ORDER BY a.check_in DESC LIMIT 150""")


def list_workouts(con, q):
    return rows(con, """SELECT w.*, m.full_name AS member_name, t.name AS trainer_name
                        FROM workout_plans w JOIN members m ON m.member_id=w.member_id
                        LEFT JOIN trainers t ON t.trainer_id=w.trainer_id
                        ORDER BY w.workout_id DESC""")


def list_trainers(con, q):
    return rows(con, """SELECT t.*, l.clients, l.weekly_classes, l.upcoming_pt
                        FROM trainers t JOIN v_trainer_load l ON l.trainer_id=t.trainer_id ORDER BY t.trainer_id""")


def list_plans(con, q):
    return rows(con, """SELECT p.*, (SELECT COUNT(*) FROM members m WHERE m.plan_id=p.plan_id AND m.status='Active') AS active_members
                        FROM membership_plans p ORDER BY p.duration_days""")


LISTERS = {"members": list_members, "classes": list_classes, "bookings": list_bookings, "payments": list_payments,
           "attendance": list_attendance, "workouts": list_workouts, "trainers": list_trainers, "plans": list_plans}


# ----------------------------------------------------------------- reports
def dashboard(con):
    refresh_expired(con)
    n = lambda sql: con.execute(sql).fetchone()[0]
    data = {
        "total_members": n("SELECT COUNT(*) FROM members"),
        "active_members": n("SELECT COUNT(*) FROM members WHERE status='Active'"),
        "expired_members": n("SELECT COUNT(*) FROM members WHERE status='Expired'"),
        "expiring_soon": n("SELECT COUNT(*) FROM members WHERE status='Active' AND expiry_date BETWEEN date('now') AND date('now','+7 day')"),
        "revenue_month": n("SELECT IFNULL(SUM(amount),0) FROM payments WHERE strftime('%Y-%m',paid_on)=strftime('%Y-%m','now')"),
        "revenue_total": n("SELECT IFNULL(SUM(amount),0) FROM payments"),
        "checkins_today": n("SELECT COUNT(*) FROM attendance WHERE date(check_in)=date('now','localtime')"),
        "inside_now": n("SELECT COUNT(*) FROM attendance WHERE check_out IS NULL AND date(check_in)=date('now','localtime')"),
        "bookings_upcoming": n("SELECT COUNT(*) FROM bookings WHERE status='Booked' AND session_date>=date('now')"),
        "trainers": n("SELECT COUNT(*) FROM trainers WHERE status='Active'"),
    }
    data["revenue_chart"] = revenue_series(con, 6)
    data["attendance_chart"] = rows(con, """SELECT date(check_in) AS day, COUNT(*) AS visits FROM attendance
                                            WHERE date(check_in) >= date('now','-6 day') GROUP BY date(check_in) ORDER BY day""")
    data["plan_mix"] = rows(con, """SELECT p.name, COUNT(m.member_id) AS members FROM membership_plans p
                                    LEFT JOIN members m ON m.plan_id=p.plan_id AND m.status='Active' GROUP BY p.plan_id""")
    return data


def revenue_series(con, months):
    got = {r["month"]: r for r in rows(con, "SELECT * FROM v_monthly_revenue")}
    out = []
    y, m = date.today().year, date.today().month
    for i in range(months - 1, -1, -1):
        mm, yy = m - i, y
        while mm <= 0:
            mm += 12
            yy -= 1
        key = "%04d-%02d" % (yy, mm)
        out.append({"month": key, "revenue": got.get(key, {}).get("revenue", 0), "payments": got.get(key, {}).get("payments", 0)})
    return out


def report(con, kind):
    refresh_expired(con)
    if kind == "revenue":
        return {
            "monthly": revenue_series(con, 12),
            "by_plan": rows(con, """SELECT p.name, COUNT(*) AS payments, ROUND(SUM(y.amount),2) AS revenue FROM payments y
                                    JOIN membership_plans p ON p.plan_id=y.plan_id GROUP BY p.plan_id ORDER BY revenue DESC"""),
            "by_method": rows(con, "SELECT method, COUNT(*) AS payments, ROUND(SUM(amount),2) AS revenue FROM payments GROUP BY method ORDER BY revenue DESC"),
            "top_members": rows(con, """SELECT m.full_name, ROUND(SUM(y.amount),2) AS paid FROM payments y
                                        JOIN members m ON m.member_id=y.member_id GROUP BY m.member_id ORDER BY paid DESC LIMIT 5"""),
        }
    if kind == "memberships":
        return {
            "by_status": rows(con, "SELECT status, COUNT(*) AS members FROM members GROUP BY status"),
            "by_plan": rows(con, """SELECT IFNULL(p.name,'No plan') AS name, COUNT(*) AS members FROM members m
                                    LEFT JOIN membership_plans p ON p.plan_id=m.plan_id GROUP BY p.plan_id ORDER BY members DESC"""),
            "new_per_month": rows(con, "SELECT strftime('%Y-%m',join_date) AS month, COUNT(*) AS joined FROM members GROUP BY 1 ORDER BY 1 DESC LIMIT 12"),
            "most_active": rows(con, """SELECT m.full_name, COUNT(a.attendance_id) AS visits FROM members m
                                        JOIN attendance a ON a.member_id=m.member_id GROUP BY m.member_id ORDER BY visits DESC LIMIT 5"""),
        }
    if kind == "schedule":
        return {
            "classes": list_classes(con, {}),
            "trainer_load": rows(con, "SELECT * FROM v_trainer_load ORDER BY clients DESC"),
            "upcoming_pt": rows(con, """SELECT b.session_date, b.session_time, m.full_name AS member_name, t.name AS trainer_name
                                        FROM bookings b JOIN members m ON m.member_id=b.member_id
                                        JOIN trainers t ON t.trainer_id=b.trainer_id
                                        WHERE b.type='PT' AND b.status='Booked' AND b.session_date>=date('now')
                                        ORDER BY b.session_date, b.session_time"""),
        }
    raise ApiError("Unknown report", 404)


def reminders(con):
    refresh_expired(con)
    return {
        "expiring": rows(con, """SELECT member_id, full_name, phone, email, expiry_date, plan_name, days_left FROM v_member_overview
                                 WHERE status='Active' AND expiry_date BETWEEN date('now') AND date('now','+10 day') ORDER BY expiry_date"""),
        "expired": rows(con, """SELECT member_id, full_name, phone, email, expiry_date, plan_name, -days_left AS days_ago FROM v_member_overview
                                WHERE status='Expired' ORDER BY expiry_date DESC LIMIT 20"""),
        "sessions": rows(con, """SELECT b.booking_id, b.session_date, b.session_time, m.full_name AS member_name,
                                        COALESCE(c.name,'Personal Training') AS title
                                 FROM bookings b JOIN members m ON m.member_id=b.member_id
                                 LEFT JOIN classes c ON c.class_id=b.class_id
                                 WHERE b.status='Booked' AND b.session_date BETWEEN date('now') AND date('now','+2 day')
                                 ORDER BY b.session_date, b.session_time"""),
    }


# ----------------------------------------------------------------- actions
def clean(body, cols):
    return {c: (None if body.get(c) in ("", None) else body[c]) for c in cols if c in body}


def create(con, res, body):
    table, pk, cols = RESOURCES[res]
    data = clean(body, cols)
    if not data:
        raise ApiError("No data supplied")
    sql = "INSERT INTO %s (%s) VALUES (%s)" % (table, ",".join(data), ",".join("?" * len(data)))
    cur = con.execute(sql, list(data.values()))
    return {"id": cur.lastrowid}


def update(con, res, rid, body):
    table, pk, cols = RESOURCES[res]
    data = clean(body, cols)
    if not data:
        raise ApiError("No data supplied")
    con.execute("UPDATE %s SET %s WHERE %s=?" % (table, ",".join(k + "=?" for k in data), pk), list(data.values()) + [rid])
    return {"ok": True}


def delete(con, res, rid):
    table, pk, _ = RESOURCES[res]
    con.execute("DELETE FROM %s WHERE %s=?" % (table, pk), (rid,))
    return {"ok": True}


def make_payment(con, body):
    member = one(con, "SELECT * FROM members WHERE member_id=?", (body.get("member_id"),))
    plan = one(con, "SELECT * FROM membership_plans WHERE plan_id=?", (body.get("plan_id"),))
    if not member or not plan:
        raise ApiError("Member and plan are required")
    start = date.today()
    if member["expiry_date"] and member["expiry_date"] >= start.isoformat():
        start = date.fromisoformat(member["expiry_date"]) + timedelta(days=1)  # renew early: extend
    end = start + timedelta(days=plan["duration_days"])
    amount = float(body.get("amount") or plan["price"])
    cur = con.execute(
        "INSERT INTO payments(member_id,plan_id,amount,method,paid_on,valid_from,valid_to) VALUES (?,?,?,?,?,?,?)",
        (member["member_id"], plan["plan_id"], amount, body.get("method") or "Cash", date.today().isoformat(), start.isoformat(), end.isoformat()))
    return {"id": cur.lastrowid, "valid_from": start.isoformat(), "valid_to": end.isoformat()}


def make_booking(con, body):
    kind = body.get("type")
    mid = body.get("member_id")
    if kind == "Class":
        cls = one(con, "SELECT * FROM classes WHERE class_id=?", (body.get("class_id"),))
        if not cls:
            raise ApiError("Class not found", 404)
        sdate = body.get("session_date") or next_date_for(cls["day_of_week"])
        if DAYS[date.fromisoformat(sdate).weekday()] != cls["day_of_week"]:
            raise ApiError("This class runs on %ss" % cls["day_of_week"])
        if sdate < date.today().isoformat():
            raise ApiError("Cannot book a date in the past")
        cur = con.execute("INSERT INTO bookings(member_id,type,class_id,session_date,session_time) VALUES (?,?,?,?,?)",
                          (mid, "Class", cls["class_id"], sdate, cls["start_time"]))
    elif kind == "PT":
        if not (body.get("trainer_id") and body.get("session_date") and body.get("session_time")):
            raise ApiError("Trainer, date and time are required")
        if body["session_date"] < date.today().isoformat():
            raise ApiError("Cannot book a date in the past")
        cur = con.execute("INSERT INTO bookings(member_id,type,trainer_id,session_date,session_time) VALUES (?,?,?,?,?)",
                          (mid, "PT", body["trainer_id"], body["session_date"], body["session_time"]))
    else:
        raise ApiError("type must be Class or PT")
    return {"id": cur.lastrowid}


def checkin(con, body):
    refresh_expired(con)
    open_row = one(con, "SELECT 1 AS x FROM attendance WHERE member_id=? AND check_out IS NULL AND date(check_in)=date('now','localtime')", (body.get("member_id"),))
    if open_row:
        raise ApiError("Member is already checked in")
    cur = con.execute("INSERT INTO attendance(member_id) VALUES (?)", (body.get("member_id"),))
    return {"id": cur.lastrowid}


def run_sql(body):
    q = (body.get("query") or "").strip().rstrip(";")
    if not re.match(r"^(select|with|pragma\s+table_info|explain)\b", q, re.I) or ";" in q:
        raise ApiError("Only a single SELECT statement is allowed in the SQL console")
    con = connect(readonly=True)
    try:
        cur = con.execute(q)
        cols = [c[0] for c in cur.description] if cur.description else []
        data = [list(r) for r in cur.fetchmany(500)]
        return {"columns": cols, "rows": data}
    except sqlite3.Error as e:
        raise ApiError(str(e))
    finally:
        con.close()


# ----------------------------------------------------------------- HTTP layer
class Handler(BaseHTTPRequestHandler):
    server_version = "IronPulse/1.0"

    def log_message(self, fmt, *args):
        sys.stderr.write("%s - %s\n" % (self.address_string(), fmt % args))

    def send_json(self, obj, code=200):
        data = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def body(self):
        n = int(self.headers.get("Content-Length") or 0)
        if not n:
            return {}
        try:
            return json.loads(self.rfile.read(n))
        except ValueError:
            raise ApiError("Invalid JSON")

    def serve_static(self, path):
        rel = "index.html" if path in ("", "/") else path.lstrip("/")
        full = os.path.normpath(os.path.join(STATIC, rel))
        if not full.startswith(STATIC) or not os.path.isfile(full):
            self.send_error(404)
            return
        with open(full, "rb") as f:
            data = f.read()
        self.send_response(200)
        self.send_header("Content-Type", mimetypes.guess_type(full)[0] or "application/octet-stream")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-cache")
        self.end_headers()
        self.wfile.write(data)

    def handle_api(self, method):
        url = urlparse(self.path)
        parts = [p for p in url.path.split("/") if p][1:]  # drop 'api'
        q = {k: v[0] for k, v in parse_qs(url.query).items()}
        body = self.body() if method in ("POST", "PUT") else {}
        con = connect()
        try:
            res = self.route(con, method, parts, q, body)
            con.commit()
            self.send_json(res)
        except ApiError as e:
            con.rollback()
            self.send_json({"error": str(e)}, e.code)
        except sqlite3.IntegrityError as e:
            con.rollback()
            msg = str(e)
            if "UNIQUE" in msg:
                msg = "Duplicate entry: that record (or time slot) already exists"
            elif "FOREIGN KEY" in msg:
                msg = "Invalid reference to a related record"
            self.send_json({"error": msg}, 409)
        except sqlite3.Error as e:
            con.rollback()
            self.send_json({"error": str(e)}, 400)
        finally:
            con.close()

    def route(self, con, method, p, q, body):
        if not p:
            raise ApiError("Not found", 404)
        head = p[0]
        if method == "GET":
            if head == "dashboard":
                return dashboard(con)
            if head == "reports" and len(p) == 2:
                return report(con, p[1])
            if head == "reminders":
                return reminders(con)
            if head in LISTERS and len(p) == 1:
                return LISTERS[head](con, q)
            if head == "members" and len(p) == 2:
                m = one(con, "SELECT * FROM v_member_overview WHERE member_id=?", (p[1],))
                if not m:
                    raise ApiError("Member not found", 404)
                m["payments"] = list_payments(con, {"member_id": p[1]})
                m["bookings"] = list_bookings(con, {"member_id": p[1]})
                m["workouts"] = rows(con, "SELECT * FROM workout_plans WHERE member_id=? ORDER BY workout_id DESC", (p[1],))
                m["attendance"] = rows(con, "SELECT * FROM attendance WHERE member_id=? ORDER BY check_in DESC LIMIT 15", (p[1],))
                return m
        if method == "POST":
            if head == "payments":
                return make_payment(con, body)
            if head == "bookings" and len(p) == 1:
                return make_booking(con, body)
            if head == "bookings" and len(p) == 3 and p[2] == "cancel":
                con.execute("UPDATE bookings SET status='Cancelled' WHERE booking_id=? AND status='Booked'", (p[1],))
                return {"ok": True}
            if head == "attendance" and len(p) == 2 and p[1] == "checkin":
                return checkin(con, body)
            if head == "attendance" and len(p) == 3 and p[2] == "checkout":
                con.execute("UPDATE attendance SET check_out=datetime('now','localtime') WHERE attendance_id=? AND check_out IS NULL", (p[1],))
                return {"ok": True}
            if head == "sql":
                return run_sql(body)
            if head in RESOURCES and len(p) == 1:
                return create(con, head, body)
        if method == "PUT" and head in RESOURCES and len(p) == 2:
            return update(con, head, p[1], body)
        if method == "DELETE" and head in RESOURCES and len(p) == 2:
            return delete(con, head, p[1])
        raise ApiError("Not found", 404)

    def do_GET(self):
        if self.path.startswith("/api/"):
            return self.handle_api("GET")
        self.serve_static(urlparse(self.path).path)

    def do_POST(self):
        self.handle_api("POST")

    def do_PUT(self):
        self.handle_api("PUT")

    def do_DELETE(self):
        self.handle_api("DELETE")


if __name__ == "__main__":
    if not os.path.exists(DB):
        print("gym.db not found - run:  python init_db.py")
        sys.exit(1)
    print("IronPulse Gym Management System running at http://localhost:%d  (Ctrl+C to stop)" % PORT)
    ThreadingHTTPServer(("127.0.0.1", PORT), Handler).serve_forever()
