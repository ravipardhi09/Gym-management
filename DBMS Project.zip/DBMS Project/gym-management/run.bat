@echo off
cd /d "%~dp0"
if not exist gym.db python init_db.py
start "" http://localhost:8000
python server.py
