# IronPulse – Gym Management System (DBMS Mini Project)

Python 3 (standard library only) + SQLite + vanilla JS with CSS-3D UI. No installs needed.

## Run
```
python init_db.py     # creates gym.db with sample data (re-run any time to reset)
python server.py      # http://localhost:8000
```
Or double-click `run.bat`.

## Files
| File | Purpose |
|---|---|
| `schema.sql` | Full database: 8 tables, constraints, indexes, 3 views, 4 triggers |
| `init_db.py` | Builds `gym.db` and loads sample data |
| `server.py` | REST API + static file server |
| `static/` | Front end (`index.html`, `style.css`, `app.js`) |

## ER summary
```
membership_plans 1──< members >──1 trainers
members 1──< payments >──1 membership_plans
members 1──< attendance
members 1──< bookings >──1 classes >──1 trainers      (type='Class')
                      └──1 trainers                   (type='PT')
members 1──< workout_plans >──1 trainers
```

## Rules enforced by the database
* `trg_payment_activates_member` – a payment sets plan, expiry date and status = Active.
* `trg_booking_capacity` – class cannot exceed capacity.
* `trg_booking_requires_active` – only active members can book.
* `trg_attendance_requires_active` – expired members cannot check in.
* Partial unique indexes – no double-booking a seat or a trainer slot.
* CHECK / FOREIGN KEY / UNIQUE constraints on every table.

## Modules
Dashboard · Members · Plans · Trainers · Classes · Bookings (class + PT) · Payments · Attendance ·
Workout Plans · Reports (revenue / memberships / schedule, printable) · Reminders · SQL Console (read-only).
