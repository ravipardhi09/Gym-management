-- =====================================================================
--  GYM MANAGEMENT SYSTEM  -  SQLite schema
--  Tables: membership_plans, trainers, members, classes, bookings,
--          payments, attendance, workout_plans
--  Extras: indexes, views, triggers (business rules enforced in the DB)
-- =====================================================================
PRAGMA foreign_keys = ON;

DROP VIEW    IF EXISTS v_member_overview;
DROP VIEW    IF EXISTS v_monthly_revenue;
DROP VIEW    IF EXISTS v_trainer_load;
DROP TABLE   IF EXISTS workout_plans;
DROP TABLE   IF EXISTS attendance;
DROP TABLE   IF EXISTS payments;
DROP TABLE   IF EXISTS bookings;
DROP TABLE   IF EXISTS classes;
DROP TABLE   IF EXISTS members;
DROP TABLE   IF EXISTS trainers;
DROP TABLE   IF EXISTS membership_plans;

-- ---------- 1. Membership plans -------------------------------------
CREATE TABLE membership_plans (
    plan_id        INTEGER PRIMARY KEY AUTOINCREMENT,
    name           TEXT    NOT NULL UNIQUE,
    duration_days  INTEGER NOT NULL CHECK (duration_days > 0),
    price          REAL    NOT NULL CHECK (price >= 0),
    description    TEXT
);

-- ---------- 2. Trainers ---------------------------------------------
CREATE TABLE trainers (
    trainer_id   INTEGER PRIMARY KEY AUTOINCREMENT,
    name         TEXT NOT NULL,
    specialty    TEXT NOT NULL,
    phone        TEXT,
    email        TEXT UNIQUE,
    hourly_rate  REAL NOT NULL DEFAULT 0 CHECK (hourly_rate >= 0),
    status       TEXT NOT NULL DEFAULT 'Active' CHECK (status IN ('Active','Inactive'))
);

-- ---------- 3. Members ----------------------------------------------
CREATE TABLE members (
    member_id    INTEGER PRIMARY KEY AUTOINCREMENT,
    full_name    TEXT NOT NULL,
    email        TEXT NOT NULL UNIQUE,
    phone        TEXT NOT NULL,
    gender       TEXT CHECK (gender IN ('Male','Female','Other')),
    dob          TEXT,
    join_date    TEXT NOT NULL DEFAULT (date('now')),
    plan_id      INTEGER REFERENCES membership_plans(plan_id) ON UPDATE CASCADE ON DELETE SET NULL,
    trainer_id   INTEGER REFERENCES trainers(trainer_id)      ON UPDATE CASCADE ON DELETE SET NULL,
    expiry_date  TEXT,                                   -- maintained by trigger on payments
    status       TEXT NOT NULL DEFAULT 'Pending'
                 CHECK (status IN ('Pending','Active','Expired','Suspended'))
);

-- ---------- 4. Group classes (weekly recurring) ---------------------
CREATE TABLE classes (
    class_id      INTEGER PRIMARY KEY AUTOINCREMENT,
    name          TEXT NOT NULL,
    trainer_id    INTEGER NOT NULL REFERENCES trainers(trainer_id) ON DELETE CASCADE,
    day_of_week   TEXT NOT NULL CHECK (day_of_week IN
                  ('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday')),
    start_time    TEXT NOT NULL,                         -- HH:MM
    duration_min  INTEGER NOT NULL DEFAULT 60 CHECK (duration_min > 0),
    capacity      INTEGER NOT NULL CHECK (capacity > 0),
    room          TEXT
);

-- ---------- 5. Bookings (class seats AND personal-training sessions) -
CREATE TABLE bookings (
    booking_id    INTEGER PRIMARY KEY AUTOINCREMENT,
    member_id     INTEGER NOT NULL REFERENCES members(member_id) ON DELETE CASCADE,
    type          TEXT NOT NULL CHECK (type IN ('Class','PT')),
    class_id      INTEGER REFERENCES classes(class_id)   ON DELETE CASCADE,
    trainer_id    INTEGER REFERENCES trainers(trainer_id) ON DELETE CASCADE,
    session_date  TEXT NOT NULL,
    session_time  TEXT NOT NULL,
    status        TEXT NOT NULL DEFAULT 'Booked' CHECK (status IN ('Booked','Cancelled','Completed')),
    created_at    TEXT NOT NULL DEFAULT (datetime('now')),
    CHECK ( (type = 'Class' AND class_id   IS NOT NULL)
         OR (type = 'PT'    AND trainer_id IS NOT NULL) )
);
-- one seat per member per class-date; one PT slot per trainer
CREATE UNIQUE INDEX ux_booking_member_class ON bookings(member_id, class_id, session_date)
        WHERE type = 'Class' AND status = 'Booked';
CREATE UNIQUE INDEX ux_booking_trainer_slot ON bookings(trainer_id, session_date, session_time)
        WHERE type = 'PT' AND status = 'Booked';

-- ---------- 6. Payments (fee history) -------------------------------
CREATE TABLE payments (
    payment_id  INTEGER PRIMARY KEY AUTOINCREMENT,
    member_id   INTEGER NOT NULL REFERENCES members(member_id) ON DELETE CASCADE,
    plan_id     INTEGER NOT NULL REFERENCES membership_plans(plan_id),
    amount      REAL    NOT NULL CHECK (amount >= 0),
    method      TEXT    NOT NULL DEFAULT 'Cash' CHECK (method IN ('Cash','Card','UPI','Bank Transfer')),
    paid_on     TEXT    NOT NULL DEFAULT (date('now')),
    valid_from  TEXT    NOT NULL,
    valid_to    TEXT    NOT NULL,
    CHECK (valid_to >= valid_from)
);

-- ---------- 7. Attendance -------------------------------------------
CREATE TABLE attendance (
    attendance_id  INTEGER PRIMARY KEY AUTOINCREMENT,
    member_id      INTEGER NOT NULL REFERENCES members(member_id) ON DELETE CASCADE,
    check_in       TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    check_out      TEXT
);

-- ---------- 8. Workout plans ----------------------------------------
CREATE TABLE workout_plans (
    workout_id  INTEGER PRIMARY KEY AUTOINCREMENT,
    member_id   INTEGER NOT NULL REFERENCES members(member_id) ON DELETE CASCADE,
    trainer_id  INTEGER REFERENCES trainers(trainer_id) ON DELETE SET NULL,
    title       TEXT NOT NULL,
    goal        TEXT,
    details     TEXT NOT NULL,
    created_on  TEXT NOT NULL DEFAULT (date('now'))
);

-- ---------- Indexes --------------------------------------------------
CREATE INDEX ix_members_status     ON members(status);
CREATE INDEX ix_members_expiry     ON members(expiry_date);
CREATE INDEX ix_payments_member    ON payments(member_id);
CREATE INDEX ix_payments_paid_on   ON payments(paid_on);
CREATE INDEX ix_attendance_member  ON attendance(member_id, check_in);
CREATE INDEX ix_bookings_date      ON bookings(session_date);

-- ---------- Triggers (business rules) --------------------------------
-- A payment activates the member and pushes the expiry date forward.
CREATE TRIGGER trg_payment_activates_member
AFTER INSERT ON payments
BEGIN
    UPDATE members
       SET plan_id     = NEW.plan_id,
           expiry_date = NEW.valid_to,
           status      = CASE WHEN status = 'Suspended' THEN 'Suspended' ELSE 'Active' END
     WHERE member_id = NEW.member_id;
END;

-- A class cannot be booked beyond its capacity.
CREATE TRIGGER trg_booking_capacity
BEFORE INSERT ON bookings
WHEN NEW.type = 'Class' AND NEW.status = 'Booked'
 AND (SELECT COUNT(*) FROM bookings
       WHERE class_id = NEW.class_id AND session_date = NEW.session_date AND status = 'Booked')
     >= (SELECT capacity FROM classes WHERE class_id = NEW.class_id)
BEGIN
    SELECT RAISE(ABORT, 'This class is full for the selected date');
END;

-- Only members with a valid, active membership can book.
CREATE TRIGGER trg_booking_requires_active
BEFORE INSERT ON bookings
WHEN NEW.status = 'Booked'
 AND (SELECT status FROM members WHERE member_id = NEW.member_id) <> 'Active'
BEGIN
    SELECT RAISE(ABORT, 'Member does not have an active membership');
END;

-- Only active members can check in.
CREATE TRIGGER trg_attendance_requires_active
BEFORE INSERT ON attendance
WHEN (SELECT status FROM members WHERE member_id = NEW.member_id) <> 'Active'
  OR (SELECT expiry_date FROM members WHERE member_id = NEW.member_id) < date('now')
BEGIN
    SELECT RAISE(ABORT, 'Membership expired or inactive - please renew before check-in');
END;

-- ---------- Views (reporting) ----------------------------------------
CREATE VIEW v_member_overview AS
SELECT m.member_id, m.full_name, m.email, m.phone, m.join_date, m.expiry_date,
       CASE WHEN m.status = 'Active' AND m.expiry_date < date('now') THEN 'Expired' ELSE m.status END AS status,
       p.name AS plan_name, t.name AS trainer_name,
       CAST(julianday(m.expiry_date) - julianday(date('now')) AS INTEGER) AS days_left,
       (SELECT COUNT(*) FROM attendance a WHERE a.member_id = m.member_id) AS visits,
       (SELECT IFNULL(SUM(amount),0) FROM payments y WHERE y.member_id = m.member_id) AS total_paid
  FROM members m
  LEFT JOIN membership_plans p ON p.plan_id = m.plan_id
  LEFT JOIN trainers t         ON t.trainer_id = m.trainer_id;

CREATE VIEW v_monthly_revenue AS
SELECT strftime('%Y-%m', paid_on) AS month,
       COUNT(*)                   AS payments,
       ROUND(SUM(amount), 2)      AS revenue
  FROM payments
 GROUP BY strftime('%Y-%m', paid_on);

CREATE VIEW v_trainer_load AS
SELECT t.trainer_id, t.name, t.specialty,
       (SELECT COUNT(*) FROM members  m WHERE m.trainer_id = t.trainer_id)                       AS clients,
       (SELECT COUNT(*) FROM classes  c WHERE c.trainer_id = t.trainer_id)                       AS weekly_classes,
       (SELECT COUNT(*) FROM bookings b WHERE b.trainer_id = t.trainer_id AND b.type = 'PT'
                                          AND b.status = 'Booked' AND b.session_date >= date('now')) AS upcoming_pt
  FROM trainers t;
