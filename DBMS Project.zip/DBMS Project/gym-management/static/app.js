/* IronPulse Gym Management - single page app (vanilla JS) */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = v => String(v ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const money = n => "₹" + Number(n || 0).toLocaleString("en-IN", { maximumFractionDigits: 0 });
const today = () => new Date().toLocaleDateString("en-CA");
const fdate = s => s ? new Date(s.replace(" ", "T")).toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" }) : "—";
const ftime = s => s ? s.slice(11, 16) : "—";
const badge = s => `<span class="badge b-${esc(String(s).replace(/\s/g, ""))}">${esc(s)}</span>`;

async function api(path, method = "GET", body) {
  const res = await fetch("/api/" + path, { method, headers: { "Content-Type": "application/json" }, body: body ? JSON.stringify(body) : undefined });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || "Request failed");
  return data;
}
function toast(msg, err = false) {
  const t = document.createElement("div");
  t.className = "toast" + (err ? " err" : "");
  t.textContent = msg;
  $("#toasts").append(t);
  setTimeout(() => t.remove(), 4200);
}
const guard = fn => async (...a) => { try { return await fn(...a); } catch (e) { toast(e.message, true); } };

/* ================= 3D primitives ================= */
// A cuboid made from 6 CSS-3D faces. centered=true places its centre on the parent's origin.
function box(w, h, d, cls = "", centered = false, extra = "") {
  const pos = centered ? `position:absolute;left:0;top:0;margin:${-h / 2}px 0 0 ${-w / 2}px;` : "";
  const f = (c, ww, hh, l, t, tr) => `<i class="f ${c}" style="width:${ww}px;height:${hh}px;left:${l}px;top:${t}px;transform:${tr}"></i>`;
  return `<div class="box ${cls}" style="width:${w}px;height:${h}px;${pos}${extra}">` +
    f("front", w, h, 0, 0, `translateZ(${d / 2}px)`) + f("back", w, h, 0, 0, `rotateY(180deg) translateZ(${d / 2}px)`) +
    f("right", d, h, (w - d) / 2, 0, `rotateY(90deg) translateZ(${w / 2}px)`) + f("left", d, h, (w - d) / 2, 0, `rotateY(-90deg) translateZ(${w / 2}px)`) +
    f("top", w, d, 0, (h - d) / 2, `rotateX(90deg) translateZ(${h / 2}px)`) + f("bottom", w, d, 0, (h - d) / 2, `rotateX(-90deg) translateZ(${h / 2}px)`) + `</div>`;
}
// Round-ish weight plate: 4 slabs rotated 45 degrees apart around the X axis.
function plate(x, thick, R, cls) {
  let s = "";
  for (let k = 0; k < 4; k++) s += `<div style="position:absolute;left:0;top:0;transform-style:preserve-3d;transform:rotateX(${k * 45}deg)">${box(thick, R * 2, R * 0.83, cls, true)}</div>`;
  return `<div style="position:absolute;left:0;top:0;transform-style:preserve-3d;transform:translateX(${x}px)">${s}</div>`;
}
function dumbbell() {
  let h = box(250, 12, 12, "steel", true) + box(60, 22, 22, "dark", true);
  for (const sg of [-1, 1]) {
    h += plate(sg * 78, 20, 62, "lime") + plate(sg * 100, 16, 50, "red") + plate(sg * 118, 12, 38, "steel");
    h += box(26, 16, 16, "dark", true, `transform:translateX(${sg * 136}px)`);
  }
  return h;
}
function miniLogo() {
  return `<div class="spin" style="animation-duration:6s;transform-origin:0 0">${box(34, 8, 8, "steel", true)}${plate(-13, 6, 18, "lime")}${plate(13, 6, 18, "lime")}</div>`;
}

// 3D bar chart. items: [{label, value, text?}]
function chart3d(items, color = "lime", fmt = v => v) {
  if (!items.length) return `<div class="chart-empty">No data yet</div>`;
  const w = 34, d = 34, gap = 28, maxH = 150, max = Math.max(...items.map(i => +i.value), 1);
  const total = items.length * (w + gap) - gap;
  const colors = { lime: "#c8ff2e", orange: "#ff6a3d", blue: "#3dc8ff", pink: "#ff4d8d", violet: "#9b6bff" };
  let bars = items.map((it, i) => {
    const hh = Math.max(6, Math.round((+it.value / max) * maxH));
    const lx = i * (w + gap);
    return `<div class="cbar" style="left:${lx}px;width:${w}px;height:${maxH}px;animation-delay:${i * 70}ms">
      <div style="position:absolute;left:0;top:${maxH - hh}px;transform-style:preserve-3d">${box(w, hh, d, "", false, `--c:${colors[color] || color}`)}</div>
      <span class="val" style="left:${-gap / 2}px;width:${w + gap}px;top:${maxH - hh - 32}px;transform:translateZ(${d / 2 + 1}px)">${esc(it.text ?? fmt(it.value))}</span>
      <span class="lab" style="left:${-gap / 2}px;width:${w + gap}px;top:${maxH + 22}px;transform:translateZ(${d / 2 + 1}px)">${esc(it.label)}</span>
    </div>`;
  }).join("");
  return `<div class="chart3d"><div class="cscene" style="width:${total}px;height:${maxH}px">
    <div class="cfloor" style="left:-40px;width:${total + 80}px;height:${d + 120}px;bottom:${-(d + 120) / 2}px"></div>${bars}</div></div>`;
}

/* ================= tilt / chart interaction (event delegation) ================= */
let tiltEl = null;
document.addEventListener("mousemove", e => {
  const chart = e.target.closest(".chart3d");
  if (chart) {
    const r = chart.getBoundingClientRect(), p = (e.clientX - r.left) / r.width;
    $(".cscene", chart).style.setProperty("--ry", (-48 + p * 44) + "deg");
  }
  const el = e.target.closest(".tilt");
  if (tiltEl && tiltEl !== el) tiltEl.style.transform = "";
  tiltEl = el;
  if (!el) return;
  const r = el.getBoundingClientRect();
  const px = (e.clientX - r.left) / r.width - .5, py = (e.clientY - r.top) / r.height - .5;
  el.style.transform = `perspective(800px) rotateY(${px * 14}deg) rotateX(${-py * 14}deg) translateZ(8px)`;
});
document.addEventListener("mouseleave", () => { if (tiltEl) tiltEl.style.transform = ""; }, true);

/* ================= modal helpers ================= */
function closeModal() { $("#modalRoot").innerHTML = ""; }
function modal(html, wide = false) {
  const root = $("#modalRoot");
  root.innerHTML = `<div class="modal-bg"><div class="modal ${wide ? "wide" : ""}">${html}</div></div>`;
  $(".modal-bg", root).addEventListener("mousedown", e => { if (e.target.classList.contains("modal-bg")) closeModal(); });
  return $(".modal", root);
}
function fieldHtml(f, v) {
  const val = v ?? f.value ?? "";
  let inp;
  if (f.type === "select") {
    inp = `<select name="${f.name}" ${f.required ? "required" : ""}>${f.blank !== false && !f.required ? `<option value="">${esc(f.blank || "—")}</option>` : ""}` +
      f.options.map(o => `<option value="${esc(o.v)}" ${String(o.v) === String(val) ? "selected" : ""}>${esc(o.t)}</option>`).join("") + `</select>`;
  } else if (f.type === "textarea") inp = `<textarea name="${f.name}" ${f.required ? "required" : ""}>${esc(val)}</textarea>`;
  else inp = `<input name="${f.name}" type="${f.type || "text"}" value="${esc(val)}" ${f.required ? "required" : ""} ${f.step ? `step="${f.step}"` : ""} ${f.min != null ? `min="${f.min}"` : ""}>`;
  return `<label class="fld ${f.full ? "full" : ""}">${esc(f.label)}${inp}</label>`;
}
function formModal({ title, fields, values = {}, submit = "Save", onSubmit, onChange }) {
  const m = modal(`<h2>${esc(title)}</h2><form><div class="form-grid">${fields.map(f => fieldHtml(f, values[f.name])).join("")}</div>
    <div class="foot"><button type="button" class="btn" data-x>Cancel</button><button class="btn primary">${esc(submit)}</button></div></form>`);
  const form = $("form", m);
  $("[data-x]", m).onclick = closeModal;
  if (onChange) form.addEventListener("change", () => onChange(form));
  form.onsubmit = async e => {
    e.preventDefault();
    const obj = Object.fromEntries(new FormData(form).entries());
    try { await onSubmit(obj); closeModal(); } catch (err) { toast(err.message, true); }
  };
  const first = $("input,select,textarea", form); if (first) first.focus();
  return m;
}
const confirmBox = (msg, yes) => {
  const m = modal(`<h2>Please confirm</h2><p>${esc(msg)}</p><div class="foot"><button class="btn" data-x>No</button><button class="btn primary" data-y>Yes</button></div>`);
  $("[data-x]", m).onclick = closeModal;
  $("[data-y]", m).onclick = async () => { try { await yes(); closeModal(); } catch (e) { toast(e.message, true); } };
};

/* ================= shared lookups ================= */
let cache = {};
async function lookups() {
  const [plans, trainers, members] = await Promise.all([api("plans"), api("trainers"), api("members")]);
  cache = { plans, trainers, members };
  return cache;
}
const planOpts = () => cache.plans.map(p => ({ v: p.plan_id, t: `${p.name} (${money(p.price)})` }));
const trainerOpts = () => cache.trainers.filter(t => t.status === "Active").map(t => ({ v: t.trainer_id, t: t.name + " — " + t.specialty }));
const memberOpts = (activeOnly = false) => cache.members.filter(m => !activeOnly || m.status === "Active").map(m => ({ v: m.member_id, t: `#${m.member_id} ${m.full_name}` }));
const methods = ["Cash", "Card", "UPI", "Bank Transfer"].map(x => ({ v: x, t: x }));
const table = (cols, rows, empty = "Nothing here yet") => rows.length ?
  `<div class="table-wrap"><table><thead><tr>${cols.map(c => `<th>${c.h}</th>`).join("")}</tr></thead><tbody>${rows.map(r => `<tr>${cols.map(c => `<td class="${c.cls || ""}">${c.f(r)}</td>`).join("")}</tr>`).join("")}</tbody></table></div>` :
  `<div class="table-wrap"><div class="empty">${empty}</div></div>`;

/* ================= views ================= */
const VIEWS = {};
const NAV = [
  ["dashboard", "📊", "Dashboard"], ["members", "👥", "Members"], ["plans", "🏷️", "Plans"], ["trainers", "🏋️", "Trainers"],
  ["classes", "📅", "Classes"], ["bookings", "🎟️", "Bookings"], ["payments", "💳", "Payments"], ["attendance", "✅", "Attendance"],
  ["workouts", "📝", "Workout Plans"], ["reports", "📈", "Reports"], ["reminders", "🔔", "Reminders"], ["sql", "🗄️", "SQL Console"],
];

VIEWS.dashboard = async el => {
  const d = await api("dashboard");
  el.innerHTML = `
  <div class="card hero tilt"><div class="txt"><h2>Train hard.<br><em>Manage smart.</em></h2>
    <p>${d.active_members} active members, ${d.inside_now} inside the gym right now and ${d.bookings_upcoming} upcoming bookings. Move your mouse over the cards and chart to explore in 3D.</p></div>
    <div class="scene3d"><div class="spin">${dumbbell()}</div><div class="shadow"></div></div></div>
  <div class="grid g-4">
    <div class="card stat c1 tilt"><h3>Active members</h3><div class="num">${d.active_members}</div><div class="sub">of ${d.total_members} registered</div><div class="emoji">💪</div></div>
    <div class="card stat c2 tilt"><h3>Revenue this month</h3><div class="num">${money(d.revenue_month)}</div><div class="sub">Lifetime ${money(d.revenue_total)}</div><div class="emoji">💰</div></div>
    <div class="card stat c3 tilt"><h3>Check-ins today</h3><div class="num">${d.checkins_today}</div><div class="sub">${d.inside_now} still inside</div><div class="emoji">🚪</div></div>
    <div class="card stat c4 tilt"><h3>Expiring in 7 days</h3><div class="num">${d.expiring_soon}</div><div class="sub">${d.expired_members} already expired</div><div class="emoji">⏳</div></div>
  </div>
  <div class="grid g-2" style="margin-top:18px">
    <div class="card"><h3>Revenue — last 6 months</h3>${chart3d(d.revenue_chart.map(r => ({ label: r.month.slice(5) + "/" + r.month.slice(2, 4), value: r.revenue, text: r.revenue >= 1000 ? Math.round(r.revenue / 1000) + "k" : r.revenue })), "lime")}</div>
    <div class="card"><h3>Visits — last 7 days</h3>${chart3d(d.attendance_chart.map(r => ({ label: fdate(r.day).slice(0, 6), value: r.visits })), "blue")}</div>
  </div>
  <div class="grid g-2" style="margin-top:18px">
    <div class="card"><h3>Active members by plan</h3>${chart3d(d.plan_mix.map(r => ({ label: r.name.split(" ")[0], value: r.members })), "orange")}</div>
    <div class="card" id="dashRem"><h3>Renewal reminders</h3><div class="muted">Loading…</div></div>
  </div>`;
  const r = await api("reminders");
  $("#dashRem").innerHTML = `<h3>Renewal reminders</h3>` + (r.expiring.length ? r.expiring.slice(0, 6).map(m => `<div class="list-item"><div><b>${esc(m.full_name)}</b><div class="small muted">${esc(m.plan_name)} · expires ${fdate(m.expiry_date)}</div></div>${badge(m.days_left + " days left")}</div>`).join("") : `<div class="muted">No memberships expiring in the next 10 days 🎉</div>`);
};

/* ---------- members ---------- */
VIEWS.members = async el => {
  await lookups();
  el.innerHTML = `<div class="toolbar"><input id="mq" placeholder="Search name, email, phone…"><select id="ms"><option value="">All statuses</option>
    ${["Active", "Expired", "Pending", "Suspended"].map(s => `<option>${s}</option>`).join("")}</select><span class="sp"></span><button class="btn primary" id="addM">＋ New member</button></div><div id="mtable"></div>`;
  const load = guard(async () => {
    const rows = await api(`members?q=${encodeURIComponent($("#mq").value)}&status=${$("#ms").value}`);
    $("#mtable").innerHTML = table([
      { h: "ID", f: r => r.member_id }, { h: "Member", f: r => `<b>${esc(r.full_name)}</b><div class="small muted">${esc(r.email)} · ${esc(r.phone)}</div>` },
      { h: "Plan", f: r => esc(r.plan_name || "—") }, { h: "Trainer", f: r => esc(r.trainer_name || "—") },
      { h: "Expiry", f: r => r.expiry_date ? fdate(r.expiry_date) + (r.status === "Active" ? `<div class="small muted">${r.days_left} days left</div>` : "") : "—" },
      { h: "Visits", f: r => r.visits }, { h: "Status", f: r => badge(r.status) },
      { h: "", cls: "act", f: r => `<button class="btn sm" data-a="view" data-id="${r.member_id}">View</button> <button class="btn sm" data-a="renew" data-id="${r.member_id}">Renew</button> <button class="btn sm" data-a="edit" data-id="${r.member_id}">Edit</button> <button class="btn sm danger" data-a="del" data-id="${r.member_id}">✕</button>` }], rows, "No members match");
    const byId = Object.fromEntries(rows.map(r => [r.member_id, r]));
    $$("#mtable [data-a]").forEach(b => b.onclick = () => memberAction(b.dataset.a, byId[b.dataset.id], load));
  });
  $("#mq").oninput = load; $("#ms").onchange = load; $("#addM").onclick = () => memberForm(null, load);
  load();
};
function memberAction(a, m, reload) {
  if (a === "view") return memberDetail(m.member_id);
  if (a === "renew") return payForm(m.member_id, reload);
  if (a === "edit") return memberForm(m, reload);
  if (a === "del") confirmBox(`Delete ${m.full_name} and all their payments, bookings and attendance?`, async () => { await api("members/" + m.member_id, "DELETE"); toast("Member deleted"); reload(); });
}
function memberForm(m, reload) {
  const f = [
    { name: "full_name", label: "Full name", required: true }, { name: "email", label: "Email", type: "email", required: true },
    { name: "phone", label: "Phone", required: true }, { name: "gender", label: "Gender", type: "select", options: ["Male", "Female", "Other"].map(x => ({ v: x, t: x })) },
    { name: "dob", label: "Date of birth", type: "date" }, { name: "trainer_id", label: "Personal trainer", type: "select", options: trainerOpts(), blank: "No trainer" },
  ];
  if (m) f.push({ name: "plan_id", label: "Plan", type: "select", options: planOpts() }, { name: "status", label: "Status", type: "select", required: true, options: ["Pending", "Active", "Expired", "Suspended"].map(x => ({ v: x, t: x })) });
  else f.push({ name: "pay_plan", label: "Plan (pay now to activate)", type: "select", options: planOpts(), blank: "Pay later" }, { name: "pay_method", label: "Payment method", type: "select", required: true, options: methods });
  formModal({
    title: m ? "Edit member" : "Register new member", fields: f, values: m || {}, submit: m ? "Save changes" : "Register",
    onSubmit: async o => {
      const { pay_plan, pay_method, ...body } = o;
      if (m) await api("members/" + m.member_id, "PUT", body);
      else {
        if (pay_plan) body.plan_id = pay_plan;
        const r = await api("members", "POST", body);
        if (pay_plan) await api("payments", "POST", { member_id: r.id, plan_id: pay_plan, method: pay_method });
      }
      toast(m ? "Member updated" : "Member registered" + (pay_plan ? " and activated" : " — record a payment to activate"));
      reload();
    },
  });
}
async function memberDetail(id) {
  const m = await api("members/" + id).catch(e => toast(e.message, true)); if (!m) return;
  const mm = modal(`<h2>${esc(m.full_name)} ${badge(m.status)}</h2>
    <dl class="kv"><dt>Email</dt><dd>${esc(m.email)}</dd><dt>Phone</dt><dd>${esc(m.phone)}</dd><dt>Joined</dt><dd>${fdate(m.join_date)}</dd>
    <dt>Plan</dt><dd>${esc(m.plan_name || "—")}</dd><dt>Valid until</dt><dd>${fdate(m.expiry_date)}</dd><dt>Trainer</dt><dd>${esc(m.trainer_name || "—")}</dd>
    <dt>Total paid</dt><dd>${money(m.total_paid)} · ${m.visits} visits</dd></dl>
    <div class="day-head">Payment history</div>${table([{ h: "Date", f: r => fdate(r.paid_on) }, { h: "Plan", f: r => esc(r.plan_name) }, { h: "Amount", f: r => money(r.amount) }, { h: "Method", f: r => r.method }, { h: "Valid", f: r => fdate(r.valid_from) + " → " + fdate(r.valid_to) }], m.payments.slice(0, 8), "No payments")}
    <div class="day-head">Upcoming &amp; past bookings</div>${table([{ h: "Date", f: r => fdate(r.session_date) + " " + r.session_time }, { h: "Session", f: r => esc(r.title) }, { h: "Type", f: r => badge(r.type) }, { h: "Status", f: r => badge(r.status) }], m.bookings.slice(-8), "No bookings")}
    <div class="day-head">Workout plan</div>${m.workouts.map(w => `<b>${esc(w.title)}</b> <span class="muted small">(${esc(w.goal || "")})</span><pre class="workout">${esc(w.details)}</pre>`).join("") || `<div class="muted">No workout plan assigned</div>`}
    <div class="foot"><button class="btn" data-x>Close</button></div>`, true);
  $("[data-x]", mm).onclick = closeModal;
}

/* ---------- plans ---------- */
VIEWS.plans = async el => {
  const plans = await api("plans");
  el.innerHTML = `<div class="toolbar"><span class="sp"></span><button class="btn primary" id="add">＋ New plan</button></div><div class="grid g-3">${plans.map(p => `
    <div class="card tilt"><h3>${esc(p.name)}</h3><div class="plan-price">${money(p.price)} <small>/ ${p.duration_days} day${p.duration_days > 1 ? "s" : ""}</small></div>
    <p class="muted small" style="margin:8px 0 14px">${esc(p.description || "")}</p><div class="row sp"><span class="badge b-Active">${p.active_members} active</span>
    <span><button class="btn sm" data-e="${p.plan_id}">Edit</button> <button class="btn sm danger" data-d="${p.plan_id}">✕</button></span></div></div>`).join("")}</div>`;
  const form = p => formModal({
    title: p ? "Edit plan" : "New plan", values: p || {}, fields: [{ name: "name", label: "Plan name", required: true, full: true }, { name: "duration_days", label: "Duration (days)", type: "number", required: true, min: 1 },
    { name: "price", label: "Price (₹)", type: "number", required: true, min: 0, step: "0.01" }, { name: "description", label: "Description", type: "textarea", full: true }],
    onSubmit: async o => { await api(p ? "plans/" + p.plan_id : "plans", p ? "PUT" : "POST", o); toast("Plan saved"); show("plans"); }
  });
  $("#add").onclick = () => form();
  $$("[data-e]").forEach(b => b.onclick = () => form(plans.find(p => p.plan_id == b.dataset.e)));
  $$("[data-d]").forEach(b => b.onclick = () => confirmBox("Delete this plan? Payments using it block deletion.", async () => { await api("plans/" + b.dataset.d, "DELETE"); show("plans"); }));
};

/* ---------- trainers ---------- */
VIEWS.trainers = async el => {
  const list = await api("trainers");
  el.innerHTML = `<div class="toolbar"><span class="sp"></span><button class="btn primary" id="add">＋ New trainer</button></div><div class="grid g-3">${list.map(t => `
    <div class="card tilt"><div class="row"><div class="avatar">${esc(t.name.split(" ").map(x => x[0]).join(""))}</div><div><b style="font-size:17px">${esc(t.name)}</b><div class="muted small">${esc(t.specialty)}</div></div></div>
    <div class="row sp" style="margin-top:14px"><span class="small">${t.clients} clients</span><span class="small">${t.weekly_classes} classes/wk</span><span class="small">${t.upcoming_pt} PT booked</span></div>
    <div class="row sp" style="margin-top:12px"><span>${money(t.hourly_rate)}/hr ${badge(t.status)}</span><span><button class="btn sm" data-e="${t.trainer_id}">Edit</button> <button class="btn sm danger" data-d="${t.trainer_id}">✕</button></span></div></div>`).join("")}</div>`;
  const form = t => formModal({
    title: t ? "Edit trainer" : "New trainer", values: t || {}, fields: [{ name: "name", label: "Name", required: true }, { name: "specialty", label: "Specialty", required: true },
    { name: "phone", label: "Phone" }, { name: "email", label: "Email", type: "email" }, { name: "hourly_rate", label: "Hourly rate (₹)", type: "number", min: 0, required: true },
    { name: "status", label: "Status", type: "select", required: true, options: ["Active", "Inactive"].map(x => ({ v: x, t: x })) }],
    onSubmit: async o => { await api(t ? "trainers/" + t.trainer_id : "trainers", t ? "PUT" : "POST", o); toast("Trainer saved"); show("trainers"); }
  });
  $("#add").onclick = () => form({ status: "Active" });
  $$("[data-e]").forEach(b => b.onclick = () => form(list.find(t => t.trainer_id == b.dataset.e)));
  $$("[data-d]").forEach(b => b.onclick = () => confirmBox("Delete this trainer and their classes?", async () => { await api("trainers/" + b.dataset.d, "DELETE"); show("trainers"); }));
};

/* ---------- classes ---------- */
VIEWS.classes = async el => {
  await lookups();
  const list = await api("classes");
  const days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
  el.innerHTML = `<div class="toolbar"><span class="muted">Weekly timetable — seats shown for the next occurrence</span><span class="sp"></span><button class="btn primary" id="add">＋ New class</button></div>` +
    days.map(dn => { const cs = list.filter(c => c.day_of_week === dn); return cs.length ? `<div class="day-head">${dn}</div><div class="grid g-3">${cs.map(c => {
      const left = c.capacity - c.booked, pct = Math.round(c.booked / c.capacity * 100);
      return `<div class="card tilt"><div class="row sp"><b style="font-size:17px">${esc(c.name)}</b><span class="badge b-Class">${esc(c.start_time)}</span></div>
      <div class="muted small">${esc(c.trainer_name)} · ${c.duration_min} min · ${esc(c.room || "")}</div>
      <div class="meter"><i style="width:${pct}%"></i></div><div class="row sp small" style="margin:6px 0 12px"><span>${c.booked}/${c.capacity} booked (${fdate(c.next_date)})</span><span class="muted">${left} seats left</span></div>
      <button class="btn sm primary" data-b="${c.class_id}" ${left <= 0 ? "disabled" : ""}>${left <= 0 ? "Full" : "Book seat"}</button> <button class="btn sm danger" data-d="${c.class_id}">✕</button></div>`; }).join("")}</div>` : ""; }).join("");
  $("#add").onclick = () => formModal({
    title: "New class", fields: [{ name: "name", label: "Class name", required: true, full: true }, { name: "trainer_id", label: "Trainer", type: "select", required: true, options: trainerOpts() },
    { name: "day_of_week", label: "Day", type: "select", required: true, options: days.map(x => ({ v: x, t: x })) }, { name: "start_time", label: "Start time", type: "time", required: true },
    { name: "duration_min", label: "Duration (min)", type: "number", required: true, value: 60 }, { name: "capacity", label: "Capacity", type: "number", required: true, value: 15 }, { name: "room", label: "Room" }],
    onSubmit: async o => { await api("classes", "POST", o); toast("Class added"); show("classes"); }
  });
  $$("[data-b]").forEach(b => b.onclick = () => {
    const c = list.find(x => x.class_id == b.dataset.b);
    formModal({
      title: `Book: ${c.name} — ${fdate(c.next_date)} ${c.start_time}`, submit: "Confirm booking", fields: [{ name: "member_id", label: "Member (active only)", type: "select", required: true, options: memberOpts(true) }],
      onSubmit: async o => { await api("bookings", "POST", { type: "Class", class_id: c.class_id, member_id: o.member_id, session_date: c.next_date }); toast("Seat booked"); show("classes"); }
    });
  });
  $$("[data-d]").forEach(b => b.onclick = () => confirmBox("Delete this class and its bookings?", async () => { await api("classes/" + b.dataset.d, "DELETE"); show("classes"); }));
};

/* ---------- bookings ---------- */
VIEWS.bookings = async el => {
  await lookups();
  el.innerHTML = `<div class="toolbar"><select id="bf"><option value="1">Upcoming only</option><option value="">All bookings</option></select><span class="sp"></span><button class="btn primary" id="pt">＋ Book personal-training session</button></div><div id="bt"></div>`;
  const load = guard(async () => {
    const rows = await api("bookings" + ($("#bf").value ? "?upcoming=1" : ""));
    $("#bt").innerHTML = table([{ h: "Date", f: r => `<b>${fdate(r.session_date)}</b> ${esc(r.session_time)}` }, { h: "Member", f: r => esc(r.member_name) }, { h: "Session", f: r => esc(r.title) },
    { h: "Type", f: r => badge(r.type) }, { h: "Trainer", f: r => esc(r.trainer_name) }, { h: "Status", f: r => badge(r.status) },
    { h: "", cls: "act", f: r => r.status === "Booked" ? `<button class="btn sm danger" data-c="${r.booking_id}">Cancel</button>` : "" }], rows, "No bookings");
    $$("#bt [data-c]").forEach(b => b.onclick = guard(async () => { await api(`bookings/${b.dataset.c}/cancel`, "POST"); toast("Booking cancelled"); load(); }));
  });
  $("#bf").onchange = load;
  $("#pt").onclick = () => formModal({
    title: "Book personal-training session", submit: "Book session", values: { session_date: today(), session_time: "18:00" },
    fields: [{ name: "member_id", label: "Member", type: "select", required: true, options: memberOpts(true) }, { name: "trainer_id", label: "Trainer", type: "select", required: true, options: trainerOpts() },
    { name: "session_date", label: "Date", type: "date", required: true }, { name: "session_time", label: "Time", type: "time", required: true }],
    onSubmit: async o => { await api("bookings", "POST", { ...o, type: "PT" }); toast("Session booked"); load(); }
  });
  load();
};

/* ---------- payments ---------- */
function payForm(memberId, reload) {
  formModal({
    title: "Record payment / renew membership", submit: "Record payment", values: { member_id: memberId || "", method: "UPI" },
    fields: [{ name: "member_id", label: "Member", type: "select", required: true, options: memberOpts() }, { name: "plan_id", label: "Plan", type: "select", required: true, options: planOpts() },
    { name: "amount", label: "Amount (₹) — blank = plan price", type: "number", step: "0.01", min: 0 }, { name: "method", label: "Method", type: "select", required: true, options: methods }],
    onSubmit: async o => { const r = await api("payments", "POST", o); toast(`Payment recorded. Valid until ${fdate(r.valid_to)}`); reload && reload(); }
  });
}
VIEWS.payments = async el => {
  await lookups();
  el.innerHTML = `<div class="toolbar"><span class="sp"></span><button class="btn primary" id="pay">＋ Record payment</button></div><div id="pt"></div>`;
  const load = guard(async () => {
    const rows = await api("payments");
    $("#pt").innerHTML = table([{ h: "#", f: r => r.payment_id }, { h: "Date", f: r => fdate(r.paid_on) }, { h: "Member", f: r => esc(r.member_name) }, { h: "Plan", f: r => esc(r.plan_name) },
    { h: "Amount", f: r => `<b>${money(r.amount)}</b>` }, { h: "Method", f: r => esc(r.method) }, { h: "Coverage", f: r => fdate(r.valid_from) + " → " + fdate(r.valid_to) }], rows, "No payments");
  });
  $("#pay").onclick = () => payForm(null, async () => { await lookups(); load(); });
  load();
};

/* ---------- attendance ---------- */
VIEWS.attendance = async el => {
  await lookups();
  el.innerHTML = `<div class="toolbar"><select id="who">${memberOpts().map(o => `<option value="${o.v}">${esc(o.t)}</option>`).join("")}</select><button class="btn primary" id="ci">Check in</button><span class="sp"></span><span class="muted small">Expired members are blocked by a database trigger</span></div><div id="at"></div>`;
  const load = guard(async () => {
    const rows = await api("attendance");
    $("#at").innerHTML = table([{ h: "Member", f: r => `<b>${esc(r.member_name)}</b>` }, { h: "Check-in", f: r => fdate(r.check_in) + " " + ftime(r.check_in) },
    { h: "Check-out", f: r => r.check_out ? ftime(r.check_out) : badge("Inside") }, { h: "Duration", f: r => r.minutes + " min" },
    { h: "", cls: "act", f: r => r.check_out ? "" : `<button class="btn sm" data-o="${r.attendance_id}">Check out</button>` }], rows, "No visits");
    $$("#at [data-o]").forEach(b => b.onclick = guard(async () => { await api(`attendance/${b.dataset.o}/checkout`, "POST"); toast("Checked out"); load(); }));
  });
  $("#ci").onclick = guard(async () => { await api("attendance/checkin", "POST", { member_id: $("#who").value }); toast("Checked in — have a great workout! 💪"); load(); });
  load();
};

/* ---------- workouts ---------- */
VIEWS.workouts = async el => {
  await lookups();
  const list = await api("workouts");
  el.innerHTML = `<div class="toolbar"><span class="sp"></span><button class="btn primary" id="add">＋ New workout plan</button></div><div class="grid g-3">${list.map(w => `
    <div class="card tilt"><div class="row sp"><b>${esc(w.title)}</b><span class="badge b-Class">${esc(w.goal || "General")}</span></div><div class="muted small">${esc(w.member_name)} · coach ${esc(w.trainer_name || "—")} · ${fdate(w.created_on)}</div>
    <pre class="workout">${esc(w.details)}</pre><button class="btn sm" data-e="${w.workout_id}">Edit</button> <button class="btn sm danger" data-d="${w.workout_id}">✕</button></div>`).join("")}</div>`;
  const form = w => formModal({
    title: w ? "Edit workout plan" : "New workout plan", values: w || {}, fields: [{ name: "member_id", label: "Member", type: "select", required: true, options: memberOpts() }, { name: "trainer_id", label: "Trainer", type: "select", options: trainerOpts(), blank: "—" },
    { name: "title", label: "Title", required: true }, { name: "goal", label: "Goal", type: "select", options: ["Weight Loss", "Muscle Gain", "Endurance", "Flexibility", "General Fitness"].map(x => ({ v: x, t: x })) },
    { name: "details", label: "Plan details", type: "textarea", required: true, full: true }],
    onSubmit: async o => { await api(w ? "workouts/" + w.workout_id : "workouts", w ? "PUT" : "POST", o); toast("Workout plan saved"); show("workouts"); }
  });
  $("#add").onclick = () => form();
  $$("[data-e]").forEach(b => b.onclick = () => form(list.find(w => w.workout_id == b.dataset.e)));
  $$("[data-d]").forEach(b => b.onclick = () => confirmBox("Delete this workout plan?", async () => { await api("workouts/" + b.dataset.d, "DELETE"); show("workouts"); }));
};

/* ---------- reports ---------- */
VIEWS.reports = async el => {
  el.innerHTML = `<div class="tabs">${["revenue", "memberships", "schedule"].map((t, i) => `<div class="tab ${i ? "" : "on"}" data-t="${t}">${t[0].toUpperCase() + t.slice(1)}</div>`).join("")}<span style="flex:1"></span><button class="btn" id="print">🖨️ Print / PDF</button></div><div id="rep"></div>`;
  const load = guard(async t => {
    const r = await api("reports/" + t); const out = $("#rep");
    if (t === "revenue") out.innerHTML = `<div class="card"><h3>Monthly revenue (12 months)</h3>${chart3d(r.monthly.map(x => ({ label: x.month.slice(5), value: x.revenue, text: x.revenue >= 1000 ? Math.round(x.revenue / 1000) + "k" : x.revenue })), "lime")}</div>
      <div class="grid g-2" style="margin-top:18px"><div><div class="day-head">By plan</div>${table([{ h: "Plan", f: x => esc(x.name) }, { h: "Payments", f: x => x.payments }, { h: "Revenue", f: x => money(x.revenue) }], r.by_plan)}</div>
      <div><div class="day-head">By payment method</div>${table([{ h: "Method", f: x => esc(x.method) }, { h: "Payments", f: x => x.payments }, { h: "Revenue", f: x => money(x.revenue) }], r.by_method)}</div></div>
      <div class="day-head">Top paying members</div>${table([{ h: "Member", f: x => esc(x.full_name) }, { h: "Total paid", f: x => money(x.paid) }], r.top_members)}`;
    if (t === "memberships") out.innerHTML = `<div class="grid g-2"><div class="card"><h3>Members by status</h3>${chart3d(r.by_status.map(x => ({ label: x.status, value: x.members })), "violet")}</div>
      <div class="card"><h3>New members per month</h3>${chart3d(r.new_per_month.slice().reverse().map(x => ({ label: x.month.slice(5), value: x.joined })), "pink")}</div></div>
      <div class="grid g-2" style="margin-top:18px"><div><div class="day-head">Members per plan</div>${table([{ h: "Plan", f: x => esc(x.name) }, { h: "Members", f: x => x.members }], r.by_plan)}</div>
      <div><div class="day-head">Most active members</div>${table([{ h: "Member", f: x => esc(x.full_name) }, { h: "Visits", f: x => x.visits }], r.most_active)}</div></div>`;
    if (t === "schedule") out.innerHTML = `<div class="day-head">Trainer workload</div>${table([{ h: "Trainer", f: x => esc(x.name) }, { h: "Specialty", f: x => esc(x.specialty) }, { h: "Clients", f: x => x.clients }, { h: "Classes / week", f: x => x.weekly_classes }, { h: "Upcoming PT", f: x => x.upcoming_pt }], r.trainer_load)}
      <div class="day-head">Weekly class schedule</div>${table([{ h: "Day", f: x => x.day_of_week }, { h: "Time", f: x => x.start_time }, { h: "Class", f: x => esc(x.name) }, { h: "Trainer", f: x => esc(x.trainer_name) }, { h: "Room", f: x => esc(x.room) }, { h: "Next seats", f: x => `${x.booked}/${x.capacity}` }], r.classes)}
      <div class="day-head">Upcoming personal-training sessions</div>${table([{ h: "Date", f: x => fdate(x.session_date) + " " + x.session_time }, { h: "Member", f: x => esc(x.member_name) }, { h: "Trainer", f: x => esc(x.trainer_name) }], r.upcoming_pt, "None scheduled")}`;
  });
  $$(".tab").forEach(t => t.onclick = () => { $$(".tab").forEach(x => x.classList.remove("on")); t.classList.add("on"); load(t.dataset.t); });
  $("#print").onclick = () => window.print();
  load("revenue");
};

/* ---------- reminders ---------- */
VIEWS.reminders = async el => {
  const r = await api("reminders");
  const send = (name, what) => toast(`Reminder queued for ${name}: ${what}`);
  el.innerHTML = `<div class="grid g-3">
    <div class="card"><h3>⏳ Expiring within 10 days (${r.expiring.length})</h3>${r.expiring.map(m => `<div class="list-item"><div><b>${esc(m.full_name)}</b><div class="small muted">${esc(m.plan_name)} · ${fdate(m.expiry_date)} · ${esc(m.phone)}</div></div><button class="btn sm" data-n="${esc(m.full_name)}" data-w="renew membership">Remind</button></div>`).join("") || `<div class="muted">All good</div>`}</div>
    <div class="card"><h3>⚠️ Recently expired (${r.expired.length})</h3>${r.expired.map(m => `<div class="list-item"><div><b>${esc(m.full_name)}</b><div class="small muted">expired ${m.days_ago} day(s) ago · ${esc(m.phone)}</div></div><button class="btn sm" data-n="${esc(m.full_name)}" data-w="membership expired">Remind</button></div>`).join("") || `<div class="muted">None</div>`}</div>
    <div class="card"><h3>🔔 Sessions in next 48h (${r.sessions.length})</h3>${r.sessions.map(s => `<div class="list-item"><div><b>${esc(s.member_name)}</b><div class="small muted">${esc(s.title)} · ${fdate(s.session_date)} ${esc(s.session_time)}</div></div><button class="btn sm" data-n="${esc(s.member_name)}" data-w="upcoming session">Remind</button></div>`).join("") || `<div class="muted">No sessions soon</div>`}</div></div>`;
  $$("[data-n]").forEach(b => b.onclick = () => send(b.dataset.n, b.dataset.w));
};

/* ---------- SQL console ---------- */
VIEWS.sql = async el => {
  const samples = [
    ["Active members", "SELECT member_id, full_name, plan_name, expiry_date, days_left FROM v_member_overview WHERE status='Active' ORDER BY days_left"],
    ["Revenue by plan", "SELECT p.name, COUNT(*) AS payments, SUM(y.amount) AS revenue\nFROM payments y JOIN membership_plans p ON p.plan_id = y.plan_id\nGROUP BY p.name ORDER BY revenue DESC"],
    ["Clients per trainer", "SELECT * FROM v_trainer_load ORDER BY clients DESC"],
    ["Busiest hours", "SELECT strftime('%H', check_in) AS hour, COUNT(*) AS visits FROM attendance GROUP BY hour ORDER BY visits DESC"],
    ["Never visited", "SELECT m.full_name FROM members m LEFT JOIN attendance a ON a.member_id = m.member_id WHERE a.attendance_id IS NULL"],
    ["Schema", "SELECT type, name FROM sqlite_master WHERE type IN ('table','view','trigger','index') AND name NOT LIKE 'sqlite_%' ORDER BY type, name"],
  ];
  el.innerHTML = `<div class="card"><h3>Run read-only SQL against gym.db</h3><div class="chips">${samples.map((s, i) => `<span class="chip" data-i="${i}">${s[0]}</span>`).join("")}</div>
    <textarea class="sqlbox" id="q" spellcheck="false">${esc(samples[0][1])}</textarea><div class="toolbar" style="margin:12px 0 0"><button class="btn primary" id="run">▶ Run query</button><span class="muted small" id="info">Only SELECT statements are accepted; the connection is opened read-only.</span></div></div><div id="res" style="margin-top:16px"></div>`;
  $$(".chip").forEach(c => c.onclick = () => { $("#q").value = samples[c.dataset.i][1]; });
  const run = async () => {
    try {
      const r = await api("sql", "POST", { query: $("#q").value });
      $("#info").textContent = `${r.rows.length} row(s)`;
      $("#res").innerHTML = r.rows.length ? `<div class="table-wrap"><table><thead><tr>${r.columns.map(c => `<th>${esc(c)}</th>`).join("")}</tr></thead><tbody>${r.rows.map(row => `<tr>${row.map(v => `<td class="mono">${esc(v ?? "NULL")}</td>`).join("")}</tr>`).join("")}</tbody></table></div>` : `<div class="table-wrap"><div class="empty">Query returned no rows</div></div>`;
    } catch (e) { toast(e.message, true); }
  };
  $("#run").onclick = run;
  $("#q").addEventListener("keydown", e => { if (e.ctrlKey && e.key === "Enter") run(); });
  run();
};

/* ================= router ================= */
async function show(name) {
  if (!VIEWS[name]) name = "dashboard";
  if (location.hash !== "#" + name) history.replaceState(null, "", "#" + name);
  $$("#nav a").forEach(a => a.classList.toggle("active", a.dataset.v === name));
  $("#pageTitle").textContent = NAV.find(n => n[0] === name)[2];
  $(".sidebar").classList.remove("open");
  const el = $("#view"); el.innerHTML = `<div class="muted">Loading…</div>`;
  try { await VIEWS[name](el); } catch (e) { el.innerHTML = `<div class="card">Could not load: ${esc(e.message)}</div>`; }
}
$("#nav").innerHTML = NAV.map(n => `<a data-v="${n[0]}"><span class="ic">${n[1]}</span>${n[2]}</a>`).join("");
$$("#nav a").forEach(a => a.onclick = () => show(a.dataset.v));
$("#menuBtn").onclick = () => $(".sidebar").classList.toggle("open");
$("#logo3d").innerHTML = `<div style="position:absolute;left:50%;top:50%;width:0;height:0;transform-style:preserve-3d">${miniLogo()}</div>`;
$("#todayPill").textContent = new Date().toLocaleDateString("en-IN", { weekday: "long", day: "numeric", month: "long", year: "numeric" });
setInterval(() => { $("#clock").textContent = new Date().toLocaleTimeString("en-IN"); }, 1000);
window.addEventListener("hashchange", () => show(location.hash.slice(1)));
show(location.hash.slice(1) || "dashboard");
